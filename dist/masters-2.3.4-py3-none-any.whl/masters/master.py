import tempfile
import re
import os
import pkg_resources
import json

from operator import itemgetter
from datetime import datetime, date, time
from collections import OrderedDict
from pathlib import Path
from string import Formatter

import toml
from openpyxl.cell.read_only import EmptyCell
from openpyxl.utils.exceptions import InvalidFileException
from openpyxl import load_workbook

from masters import app, Base, get_file_name


# Create a formatter for writing master file
class MasterFile(Formatter):
    def __init__(self, code, year, version, fields):
        super().__init__()

        self.name = get_file_name(code, 'txt', year)
        self.path = Path(tempfile.gettempdir(), self.name)
        self.header, self.separator, self.footer, self.line_format = self._build(code, year, version, fields)
        self.key, self.month = None, ''

    def __enter__(self):
        self.file = open(self.path, 'w+')
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.file.close()

    # Generate header, separation line, footer and format for data line
    @staticmethod
    def _build(code, year, version, fields):
        # Build header
        version = version[code] if code in version else version['master']
        header = app.config[code]['header'].format(version=version, year=year,
                                                   updated=datetime.now().strftime('%B %d, %Y'),
                                                   initials=app.config['initials'])
        # Find the longest line to generate separator
        line_length = max([len(line) for line in header.splitlines()])
        separator = '-' * line_length + '\n'
        # Build format for this formatter
        columns = OrderedDict(**app.config['master']['format'])
        for key, value in app.config[code]['format'].items():
            columns[key] = value
        line_format = [fmt.replace('{', '{{{}:'.format(code)) for code, fmt in columns.items()]
        return header, separator, f"{separator}{version}\n", f"|{'|'.join(line_format)}|\n"

    # Write line
    def write(self, ses):
        month = ses['START'].strftime('%b')
        if month != self.month:
            self.month = month
            self.file.write(self.separator)
        self.file.write(self.format(self.line_format, **ses))

    # Write header
    def write_header(self):
        self.file.write(self.header)

    # Write footer
    def write_footer(self):
        self.file.write(self.footer)

    # get the field name for the next format_field request
    def get_field(self, field_name, args, kwargs):
        self.key = field_name
        return super().get_field(field_name, args, kwargs)

    # do special formatting for some fields
    def format_field(self, value, format_spec):
        if self.key in ['DATE', 'TIME']:
            value = value.strftime(format_spec).upper()
            format_spec = ''
        elif self.key == 'DUR' and format_spec == '%H:%M':
            hours, remainder = divmod(value, 1)
            value = f'{int(hours):2d}:{int(remainder*60):02d}'
            format_spec = ''
        elif self.key == 'STATUS':
            if isinstance(value, datetime):
                value = value.strftime(format_spec).upper()
                format_spec = ''
            else:
                format_spec = '<{:d}s'.format(len(date.today().strftime(format_spec).upper()))
        elif self.key in ['PF', 'MK4NUM'] and not isinstance(value, (int, float)):
            format_spec = '<{:d}s'.format(int(re.sub(r"\D", ' ', format_spec).strip().split()[0]))
        value = ' ' if value is None else value
        return format(value, format_spec)

    def get_value(self, key, args, kwargs):
        self.key = key
        return kwargs[key] if isinstance(key, str) else super().get_value(key, args, kwargs)


# Class to process master Excel files
class XLMaster(Base):

    def __init__(self, path):
        super().__init__()
        # Extract information from filename
        self.path, self.name, self.ext = path, path.name, path.suffix
        self.year = re.sub(r"\D", ' ', self.name).strip()

        self.type, self.sessions = None, []

        self.folder = app.config['folder']
        self.version = {'master': 'UNKNOWN', 'media': 'UNKNOWN'}

        self.format_path, self.valid_codes = self.get_formats()
        self.ns_codes_path, self.ns_codes = self.get_ns_codes()
        self.media_key_path, self.media_sizes = self.get_media_keys()
        self.today = date.today()
        self.constrains = app.config['master']['constrains']
        self.fields = OrderedDict()
        self.old_code_constrain, self.fs10 = self.get_fs_10_stations()
        self.get_session_type = self.get_session_type_dict().get

    # Read master-format file and extract valid codes
    def get_formats(self):
        name = app.config.get('master-format', 'master-format.txt')
        if isinstance(name, dict):
            name = os.path.basename(name['path'])
        path = Path(self.folder, name)
        if not path.exists():
            self.exit(error=f'{path} does not exist.')

        is_start = re.compile(r'^\s+(\S+)\s+CODES', re.MULTILINE).search
        is_end = re.compile(r'^\s+end\s+\S+\s+CODES', re.MULTILINE).search

        # Load accepted data code for specific fields
        code, valid_codes = None, {}
        with open(path) as file:
            for line in file:
                if line.startswith('##'):
                    self.version['master'] = line.strip()
                elif is_end(line):
                    code = None
                elif code:
                    valid_codes[code].append(line.split()[0])
                else:
                    m = is_start(line)
                    if m:
                        code = m.group(1)
                        valid_codes[code] = []
        return path, valid_codes

    # Read ns-codes file and extract station codes
    def get_ns_codes(self):
        name = app.config.get('ns-codes', 'ns-codes.txt')
        if isinstance(name, dict):
            name = os.path.basename(name['path'])
        path = Path(self.folder, name)
        if not path.exists():
            self.exit(error=f'{path} does not exist.')
        ns_codes = []
        with open(path) as file:
            for line in file:
                info = line.split()
                if not info[0].startswith('*') and info[1] != '--------':
                    ns_codes.append(info[0].capitalize())
        return path, ns_codes

    # Read media-key file and extract disk size codes
    def get_media_keys(self):
        name = app.config.get('media-key', 'media-key.txt')
        if isinstance(name, dict):
            name = os.path.basename(name['path'])
        path = Path(self.folder, name)
        if not path.exists():
            self.exit(error=f'{path} does not exist.')
        sizes = []
        with open(path) as file:
            for line in file:
                if line.startswith('a = type of media'):
                    break
            else:
                self.exit(error='media-key.txt do not have type media')
            for line in file:
                if '=' in line:
                    sizes.append(line.strip()[0])
        return path, set(sizes)

    # Sort list of codes stored in a string of length=n
    @staticmethod
    def sort_list(self, stations, n):
        return sorted([stations[i:i + n] for i in range(0, len(stations), n)])

    # Validate station information
    def validate_station_info(self, ses, cell, hdr):
        has_media = self.type == 'master'
        if not cell.value or not cell.value.strip():
            return '  ', '    '
        value = cell.value.replace('-', '').strip()
        sta = value[0:2]
        if has_media and (len(value) != 4 or not value[2].isdigit() or value[3] not in self.media_sizes):
            self.add_error(ses, f'invalid information [{value}] in column {hdr}')
        if sta not in self.ns_codes:
            self.add_error(ses, f'invalid station code [{sta}] in column {hdr}')

        return sta, value

    # Group by participating and non-participating stations and sort each groups
    def format_list(self, stations, n):
        groups = ''.join(stations).split()
        for i in range(0, len(groups)):
            lst = sorted([groups[i][j:j + n] for j in range(0, len(groups[i]), n)])
            # lst = self.sort_list(groups[i], n)
            groups[i] = ''.join(lst)
        return ' -'.join(groups)

    # Validate each sessions
    def validate_session(self, ses, stations):
        if app.args.v1 and ses['DATE'].year > 2022:
            ses['EXPERIMENT'] = ses['CODE'].upper()
        # Check constrains on some elements
        for code, constrain in self.constrains.items():
            if len(ses[code]) > constrain:
                self.add_error(ses, f'{code} {ses[code]} has more than {constrain:d} characters')
        # Check that DATE, TIME and DOY are valid
        if not isinstance(ses['DATE'], datetime):
            self.add_error(ses, f'invalid DATE {str(ses["DATE"])}')
        elif ses['DATE'].strftime('%Y') != self.year:
            self.add_error(ses, f'invalid DATE {ses["DATE"].strftime("%Y-%m-%d")}')
        if not isinstance(ses['TIME'], time):
            self.add_error(ses, f'invalid TIME {str(ses["TIME"])}')
        elif int(ses['DATE'].strftime('%j')) != int(ses['DOY']):
            self.add_error(ses, f'invalid DOY {str(ses["DOY"])}')
        if isinstance(ses['DATE'], date) and isinstance(ses['TIME'], time):
            ses['START'] = datetime.combine(ses['DATE'].date(), ses['TIME'])
            ses['DATE'] = ses['DATE'].date()
        if len(ses['CODE']) > self.old_code_constrain:
            not_v10 = [code for code in stations if code.strip() and code not in self.fs10]
            if not_v10:
                self.add_error(ses, f'CODE too long for [{",".join(not_v10)}]! Maximum is {self.old_code_constrain}')

        # Validate SKED, CORR, SUBM codes
        for code, items in self.valid_codes.items():
            if code not in ['STATUS', 'DBC'] and ses[code] not in items:
                self.add_error(ses, f'invalid {code} code {ses[code]}')
        # ses['DBC'] = '' if ses['DATE'].year > 2022 else ses['DBC']
        if not app.args.v1:
            ses['EXPERIMENT'] = self.get_session_type(ses['CODE'].strip().upper(), ses['EXPERIMENT'])
            ses['CODE'] = ses['CODE'].lower()

        if self.type == 'master':
            # Validate status codes if master schedule
            if not ses['STATUS']:
                if isinstance(ses['DATE'], date) and ses['DATE'] <= self.today:
                    self.add_error(ses, 'STATUS code is blank!', debug=self.debug)
                if self.debug:
                    ses['STATUS'] = 'Wt_tape'
            elif not isinstance(ses['STATUS'], datetime) and ses['STATUS'] not in self.valid_codes['STATUS']:
                self.add_error(ses, f'STATUS code {ses["STATUS"]} is not valid', debug=self.debug)

        return ses

    # Read master or vgos format
    def read_master(self, sheet):
        # Read fields from first row
        rows = sheet.iter_rows()
        row = next(rows)
        for cell in row:
            if isinstance(cell, EmptyCell):
                continue
            if not isinstance(cell.value, str):
                break
            self.fields[cell.column] = cell.value

        if 'DELAY' not in self.fields.values():
            self.fields[1000] = 'DELAY'

        # Read data
        sessions = []
        for row in rows:
            ses, master, media = {}, [], []
            for cell in row:
                # Check if first cell is empty
                if isinstance(cell, EmptyCell):
                    continue
                if 'row' not in ses:
                    ses['row'] = cell.row

                field = self.fields.get(cell.column, None)
                if field:
                    ses[field] = cell.value
                    if field.startswith('Stat'):
                        sta, size = self.validate_station_info(ses, cell, field)
                        media.append(size)
                        master.append(sta)

            if not ses.get('DATE', None):
                continue

            # Validate this session
            ses = self.validate_session(ses, master)
            # Format station codes and media
            ses['master'] = self.format_list(master, 2)
            ses['media'] = self.format_list(media, 4)

            if 'DELAY' not in ses:
                ses['DELAY'] = 0

            sessions.append(ses)

        # Sort by date
        self.sessions = sorted(sessions, key=itemgetter('START'))
        return not self.has_errors

    def read_intensive(self, sheet):
        # Read fields from first line
        fields = OrderedDict()
        rows = sheet.iter_rows()
        row = next(rows)
        for cell in row:
            if isinstance(cell, EmptyCell):
                continue
            if isinstance(cell.value, str):
                last = cell.value.strip()
            fields[cell.column] = last

        # Read data
        sessions = []
        for row in rows:
            ses = {}

            master = []
            for cell in row:
                # Check if first cell is empty
                if isinstance(cell, EmptyCell) or cell.value == '|':
                    continue
                if 'row' not in ses:
                    ses['row'] = cell.row

                field = fields.get(cell.column, None)
                if field:
                    if field == 'STATIONS':
                        sta, _ = self.validate_station_info(ses, cell, field)
                        master.append(sta)
                    else:
                        ses[field] = cell.value

            if not ses.get('DATE', None):
                continue

            # Validate this session
            ses = self.validate_session(ses, master)

            # Format station codes
            ses['master'] = self.format_list(master, 2)
            ses['DELAY'] = 0
            ses['MK4NUM'] = ''

            sessions.append(ses)

        # Rebuild fields
        self.fields = OrderedDict()
        for code, item in fields.items():
            if item not in self.fields.values():
                self.fields[code] = item
        self.fields[1001] = 'DELAY'
        self.fields[1002] = 'MK4NUM'

        # Sort by date
        self.sessions = sorted(sessions, key=itemgetter('START'))

        return not self.has_errors

    # Process file
    def process(self):

        # Make sure file exists
        if not os.path.exists(self.path):
            self.exit(error='Could not find {}'.format(self.path))
        # Make sure it is an Excel file
        try:
            xlsx = load_workbook(self.path, read_only=True, data_only=True)
        except InvalidFileException:
            self.exit(error='{} not a valid Excel file'.format(self.name))

        # Use first sheet
        sheet = xlsx[xlsx.sheetnames[0]]

        # Determine file type and process it
        name = self.name.lower()
        if 'int' in name:
            self.type = 'intensives'
            return self.read_intensive(sheet)
        self.type = 'vgos' if 'vgos' in name else 'master'

        return self.read_master(sheet)

    # Write temporary txt file
    def write_file(self, code):
        type_id = code if code in self.version else 'master'
        with MasterFile(code, self.year, self.version, self.fields) as file:
            file.write_header()
            for session in self.sessions:
                session['STATIONS'] = session[type_id]
                file.write(session)
            file.write_footer()
            return file.path

    def make_master(self):
        return self.write_file(self.type)

    def make_media(self):
        if self.type == 'master':
            self.version['media'] = app.config['media'].get('version', self.version['master'])
            return self.write_file('media')
        return None

    @staticmethod
    def get_fs_10_stations():
        f = pkg_resources.resource_stream(__name__, 'data/fs-10.toml')
        data = toml.loads(f.read().decode('utf-8'))
        return data['old_code_constrain'], data['fs-10']

    @staticmethod
    def get_session_type_dict():
        f = pkg_resources.resource_stream(__name__, 'data/types.json')
        data = json.loads(f.read().decode('utf-8'))
        return {ses_id.upper(): ses_type.upper() for ses_type, sessions in data.items() for ses_id in sessions}




