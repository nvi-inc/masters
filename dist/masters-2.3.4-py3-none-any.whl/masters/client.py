import socket
import re
from stat import S_IMODE

from paramiko import SSHClient, SSHException, BadHostKeyException, AuthenticationException
from paramiko import AutoAddPolicy


class Client:
    def __init__(self, server):
        self.server = server
        self.client = SSHClient()
        self.client.set_missing_host_key_policy(AutoAddPolicy())
        self.sftp = None
        if self.server.get('id_rsa', '').split():
            self.client.load_system_host_keys(self.server['id_rsa'])

        self.uid = self.gid = self.error = None
        self.connected = False

    def __enter__(self):
        self.connect()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        try:
            self.sftp.close()
            self.client.close()
        except AttributeError:
            pass

    # Connect to remote server
    def connect(self):
        pw = None if 'id_rsa' in self.server else self.server['password']
        try:
            self.client.connect(self.server['host'], port=self.server['port'],
                                username=self.server['user'], password=pw)
            self.sftp = self.client.open_sftp()
            self.connected = True
        except (BadHostKeyException, AuthenticationException, SSHException, socket.error) as err:
            self.error = str(err)
            self.connected = False

    def exec(self, cmd):
        lines = []
        try:
            std_in, std_out, std_err = self.client.exec_command(cmd)
            std_in.close()
            # Read output
            while True:
                line = std_out.readline()
                if not line:
                    break
                lines.append(line)
            std_out.close()
        except SSHException:
            pass

        return lines

    # Get uid and gid of user on remote server
    def getids(self):
        if not self.uid or not self.gid:
            for info in self.exec('id {}'.format(self.server['user']))[0].split():
                if info.startswith('uid='):
                    self.uid = int(re.sub(r"\D", '', info).strip())
                if info.startswith('groups='):
                    for group in info.split(','):
                        if self.server['group'] in group:
                            self.gid = int(re.sub(r"\D", '', group).strip())
                            break

        return self.uid, self.gid

    # Change mode of file on remote server
    def chmod(self, remote_path, mode):
        mode = int(mode, 8) if isinstance(mode, str) else mode
        uid, gid = self.getids()
        stats = self.sftp.stat(remote_path)
        # No stats so file does not exist
        if not stats:
            return False, 'file does not exist'
        # Change group
        if gid != stats.st_gid:
            self.sftp.chown(remote_path, int(uid), int(gid))
        if mode != S_IMODE(stats.st_mode):
            self.sftp.chmod(remote_path, mode)
        return True, ''

    # Copy local file to remove server
    def put(self, local_path, remote_path, setmode=False):
        try:
            self.sftp.put(local_path, remote_path)
            if setmode:
                return self.chmod(remote_path, '664')
        except Exception as err:
            return False, str(err)
        return True, ''

    # Copy file to remote server and execute command
    def put_and_exec(self, local_path, remote_path, cmds, setmode=False):
        ok, err = self.put(local_path, remote_path, setmode)
        if not ok:
            return ok, err
        answer = []
        for cmd in cmds:
            command = '{} {}'.format(cmd, remote_path)
            answer.append(self.exec(command))
        return True, answer

    # Get file from remote server
    def get(self, remote_path, local_path):
        try:
            self.sftp.get(remote_path, local_path)
        except Exception:
            return False

        return True

    # Remove files on remote server
    def remove(self, files):
        if isinstance(files, str):
            files = [files]
        try:
            for file in files:
                self.sftp.remove(file)
        except Exception:
            return False

        return True
