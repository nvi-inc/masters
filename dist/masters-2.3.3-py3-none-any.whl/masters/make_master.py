import os
from tempfile import gettempdir
from pathlib import Path

from masters import app, get_file_name, get_master_file, upload_files, exec_commands
from masters.master import XLMaster
from masters.notes import Notes
from masters.email import Email


def main():
    import argparse

    parser = argparse.ArgumentParser(description='Generate master file')
    parser.add_argument('-c', '--config', help='config file', required=True)
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument('-master', action='store_true')
    group.add_argument('-intensives', action='store_true')
    group.add_argument('-vgos', action='store_true')
    parser.add_argument('-v1', action='store_true')
    parser.add_argument('-json', action='store_true')
    parser.add_argument('year', help='master file year', type=int)

    app.init(parser.parse_args())

    with XLMaster(get_master_file()) as master:
        if master.process():
            # Files to be transferred for backup
            backup = [Path(path) for path
                      in [master.path, master.format_path, master.ns_codes_path, master.media_key_path]]
            # Make master and media file
            files = [Path(master.make_master())]
            path = master.make_media()
            if path:
                files.append(Path(path))
            # Make note text file from docx file
            doc_path = os.path.join(master.folder, get_file_name(master.type, 'docx', master.year))
            backup.append(Path(doc_path))
            if not os.path.exists(doc_path):
                master.exit(error=f'Could not find {doc_path}')
            path = os.path.join(gettempdir(), get_file_name(master.type, 'notes', master.year))
            files.append(Path(path))
            notes = Notes(doc_path)
            notes.save_txt(path)

            # Send files to external server
            upload_files(master, files, 'master')
            upload_files(master, backup, 'backup')
            exec_commands(master)
            # Prepare email
            email = Email(master.type)
            email.mailto(master.year, notes)


if __name__ == '__main__':

    import sys
    sys.exit(main())
