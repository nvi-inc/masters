from datetime import datetime
from urllib.parse import quote
import webbrowser
import os

from masters import app
from masters.notes import Notes


class Email:

    def __init__(self, code='master'):
        info = app.config['email']
        self.to = info[code]['to']
        self.cc = info[code]['cc'] if 'cc' in info[code] else []
        self.body = info['body']
        self.subject = info['subject']
        self.label = ' ' if code == 'master' else ' {} '.format(code)

    # Split comment to keep each line in paragraph smaller than max_length
    def split_comments(self, text):
        if len(text) <= Notes.max_length:
            return [text]
        index = text[:Notes.max_length].rfind(' ')
        return [text[:index].strip()] + self.split_comments(text[index:].strip())

    def make_notes(self, notes):
        today = datetime.now().strftime('%B %d')
        accepted = []
        # Keep blocks with last date only
        for block in notes.blocks:
            if block['date'] == today or (accepted and not block['date']):
                accepted.append(block)
            else:
                accepted = []

        # Write notes
        email_notes = []
        for block in accepted:
            if block['date']:
                email_notes.append(block['date'])
            comments = notes.build_text_paragraph(block['text'])
            for comment in comments:
                email_notes.append('{}{}'.format(' '*15, comment))
            email_notes.append('')
        return today, email_notes

    def mailto(self, year, notes):
        today, notes = self.make_notes(notes)

        updated = datetime.now().strftime('%B %d, %Y')
        body = quote(self.body.format(updated=updated, year=year, label=self.label, date=today, notes='\n'.join(notes)),'')
        subject = quote(self.subject.format(year=year, label=self.label), '')

        # Create mailto message
        separator = ',' if os.name == 'posix' else ';'
        to = quote(separator.join(self.to).strip(),'@,')
        cc = 'cc=' + quote(separator.join(self.cc).strip(),'@,') + '&' if self.cc else ''

        mailto = "mailto:{}?{}subject={}&body={}".format(to, cc, subject, body)
        webbrowser.open(mailto)


    
