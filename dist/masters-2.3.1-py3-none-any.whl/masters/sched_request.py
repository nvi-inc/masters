from masters import app
from masters import get_master_file, get_file_name
from masters.master import XLMaster
from string import Formatter
from urllib.parse import quote
import webbrowser
import os
import toml

if not os.name == 'posix':
    from win32com.client import Dispatch


class ScheduleRequest:

    def __init__(self, agency, force_text=False):
        # Set options to master schedule
        year = app.args.year
        # Initialize class with data from agency
        self.agency = agency
        self.antennas = self.agency['antennas']
        names = list(self.antennas.values())
        antenna_names = names[0] if len(names) == 1 else '{} and {}'.format(', '.join(names[:-1]), names[-1])
        plural = 's' if len(names) > 1 else ''

        self.to = self.agency.get('to', [])
        self.cc = self.agency.get('cc', [])

        request = app.config['request']
        self.subject = request['subject'].format(year=year, antennas=antenna_names)
        self.text = request['text'].format(greeting=self.agency['greeting'], antennas=antenna_names, plural=plural)

        # Check if html could be use
        if os.name != 'posix' and not force_text:
            self.fmt = HTMLformatter(request['header'], request['format'])
            self.display = self.display_outlook
        else:
            self.fmt = TEXTformatter(request['header'], request['format'])
            self.display = self.display_mailto

    # Build
    def build(self, master):
        self.fmt.body_begin()
        self.fmt.body_text(self.text)

        for sta_id, name in self.antennas.items():
            self.fmt.antenna_begin(name)
            rec = 0
            for ses in master.sessions:
                if sta_id in ses['master']:
                    rec += 1
                    ses['rec'] = rec
                    ses['STATIONS'] = ses['master']
                    self.fmt.session(ses)
            self.fmt.antenna_end()

        self.fmt.body_end()

    def display_outlook(self):

        outlook = Dispatch("Outlook.Application")

        mail = outlook.CreateItem(0)

        separator = ',' if os.name == 'posix' else ';'
        mail.to = separator.join(self.to).strip()
        mail.cc = separator.join(self.cc).strip()
        mail.subject = self.subject
        mail.HTMLBody = self.fmt.build_text()
        mail.Display(False)

    def display_mailto(self):
        subject = quote(self.subject)
        body = quote(self.fmt.build_text())

        # Create mailto message
        separator = ',' if os.name == 'posix' else ';'
        to = quote(separator.join(self.to).strip(), '@,')
        cc = quote('cc={}&'.format(separator.join(self.cc).strip()), '@,') if self.cc else ''

        mailto = "mailto:{}?{}subject={}&body={}".format(to, cc, subject, body)
        webbrowser.open(mailto)


# Write body in HTML
class HTMLFormatter(Formatter):

    def __init__(self, header, format_dict):

        self.header = header
        self.fmt = self._build_format(format_dict)
        self.lines, self.key = [], None

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        pass

    # Build format for this formatter
    @staticmethod
    def _build_format(format_dict):
        full_fmt = ['<td>{rec:d}</td>']
        for code, fmt in format_dict.items():
            if code == 'Stat1':
                code = 'STATIONS'
            elif code.startswith('Stat'):
                continue
            fmt = fmt.replace('{', '{{{}:'.format(code))
            if fmt:
                full_fmt.append(f'<td>{fmt}</td>')
        full_fmt.append('</tr>')
        return ''.join(full_fmt)

    # Begin body
    def body_begin(self):
        self.lines.append('<html><body>')

    # End body
    def body_end(self):
        self.lines.append('</body></html>')

    # Add text
    def body_text(self, text):
        self.lines.append('<br>'.join(text.splitlines()+['']))

    # Start antenna data
    def antenna_begin(self, name):
        self.lines.append('<h3>{}</h3>'.format(name))
        self.lines.append('<table style=\"padding-right: 10px;\">')
        line = '<thead><tr style=\"font-weight:bold\"><td style=\"text-align:right\"></td>'
        for word in self.header.split():
            if word == 'DUR':
                line += '</td><td style=\"text-align:center\"></td>'
            else:
                line += '<td>{}</td>'.format(word.capitalize())
        line += '</tr></thead><tbody>'
        self.lines.append(line)

    # End antenna data
    def antenna_end(self):
        self.lines.append('</tbody></table><br>')

    # Write line
    def session(self, ses):
        self.lines.append(self.format(self.fmt, **ses))

    def get_field(self, field_name, args, kwargs):
        # get the field name for the next format_field request
        self.key = field_name
        return Formatter.get_field(self, field_name, args, kwargs)

    def format_field(self, value, format_spec):
        # do special formatting for some fields
        if self.key in ['DATE', 'TIME']:
            value = value.strftime(format_spec).upper()
            format_spec = ''
        value = ' ' if value is None else value
        return format(value, format_spec).strip()

    def get_value(self, key, args, kwds):
        self.key = key
        return kwds[key] if isinstance(key, str) else Formatter.get_value(key, args, kwds)

    def build_text(self):
        return ''.join(self.lines)


# Write body in text mode.
class TEXTFormatter(Formatter):

    def __init__(self, header, format_dict):
        self.header = header
        self.fmt = self.build_format(format_dict)
        self.lines, self.key = [], None

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        pass

    # Build format for this formatter
    @staticmethod
    def build_format(format_dict):
        full_fmt = ['{rec:3d} ']
        for code, fmt in format_dict.items():
            if code == 'Stat1':
                code = 'STATIONS'
            elif code.startswith('Stat'):
                continue
            fmt = fmt.replace('{', '{{{}:'.format(code))
            if fmt:
                full_fmt.append(fmt)
        return ''.join(full_fmt)

    # Begin body
    def body_begin(self):
        pass

    # End body
    def body_end(self):
        pass

    # Add text
    def body_text(self, text):
        for line in text.splitlines():
            self.lines.append(line)

    # Start antenna data
    def antenna_begin(self, name):
        self.lines.append(f'{name}\n')
        self.lines.append(self.header)

    # End antenna data
    def antenna_end(self):
        self.lines.append('')

    # Write line
    def session(self, ses):
        self.lines.append(self.format(self.fmt, **ses))

    def get_field(self, field_name, args, kwargs):
        # get the field name for the next format_field request
        self.key = field_name
        return Formatter.get_field(self, field_name, args, kwargs)

    def format_field(self, value, format_spec):
        # do special formatting for some fields
        if self.key in ['DATE', 'TIME']:
            value = value.strftime(format_spec).upper()
            format_spec = ''
        value = ' ' if value is None else value
        return format(value, format_spec)

    def get_value(self, key, args, kwds):
        self.key = key
        if isinstance(key, str):
            return kwds[key]
        else:
            Formatter.get_value(key, args, kwds)

    def build_text(self):
        return '\n'.join(self.lines)


def main():

    import argparse

    parser = argparse.ArgumentParser(description='Generate master file')
    parser.add_argument('-c', '--config', help='config file', required=True)
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument('-master', action='store_true')
    group.add_argument('-intensives', action='store_true')
    group.add_argument('-vgos', action='store_true')
    parser.add_argument('-json', action='store_true')
    parser.add_argument('-text', action='store_true')
    parser.add_argument('year', help='master file year', type=int)
    parser.add_argument('agency', help='agency code')

    app.init(parser.parse_args())

    # Test if agency in list of agencies
    agency = toml.load(os.path.join(app.config['folder'], app.config['agencies'])).get(app.args.agency, None)
    if not agency:
        print(f'{app.args.agency} not a valid agency')
        exit(0)

    app.config['show'] = False

    with XLMaster(get_master_file()) as master:
        if master.process():
            request = ScheduleRequest(agency, force_text=app.args.text)
            request.build(master)
            request.display()


if __name__ == '__main__':

    import sys
    sys.exit(main())
