import os
import sys
import toml


# Get application input options and parameters
def init(args):
    # Initialize global variables
    this_module = sys.modules[__name__]
    setattr(this_module, 'args', args)  # Set default options for this app
    try:
        # Read config file in toml format
        setattr(this_module, 'config', toml.load(os.path.expanduser(args.config)))
        return args
    except FileNotFoundError as exc:
        print(f'Problem opening {args.config}! File not found')
    except Exception as exc:
        print(f'Problem reading {args.config} {str(exc)}')
    sys.exit(0)
