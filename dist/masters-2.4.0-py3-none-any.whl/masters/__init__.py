import os
from pathlib import Path
from pathlib import PurePosixPath
from tempfile import gettempdir
from datetime import datetime
import webbrowser

import tkinter as tk
import tkinter.simpledialog
import toml
import json

from masters import app
from masters.client import Client

passwords = {}


# Base class handling errors and messages
class Base:

    def __init__(self):
        self.debug, self.show = app.config.get('debug', False), app.config.get('show', False)
        self.has_errors, self.messages = None, []

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        if app.args.json:
            answer = {'status': 'Failed' if self.messages else 'Ok'}
            if self.messages:
                answer['messages'] = self.messages
            print(json.dumps(answer))
        elif self.has_errors or self.show:
            self.show_status()

    # exit with error message
    def exit(self, error=None):
        if error:
            self.has_errors = True
            self.messages.append({'type': 'ERROR', 'text': error})
        if self.messages:
            print(f'Terminate with {"error" if self.has_errors else "comments"}.')
            [print(f'{msg["type"]} : {msg["text"]}') for msg in self.messages]
        exit(0)

    # Add code and row information to message and append to appropriate group
    def add_error(self, ses, error, debug=False):
        if not debug:
            self.has_errors = True
        extra = 'debug' if self.debug else ''
        msg = {'type': 'ERROR', 'text': f'{ses["CODE"]} ({ses["row"]:d}) {error} {extra}'}
        self.messages.append(msg)

    # Add information to messages
    def add_information(self, info):
        for lines in info:
            if isinstance(lines, str):
                lines = [lines]
            for line in lines:
                msg = {'type': 'INFO', 'text': line.replace('\n', '')}
                self.messages.append(msg)

    # Open file with messages
    def show_status(self):
        if self.messages:
            path = os.path.join(gettempdir(), f'msg-{datetime.now().strftime("%Y%m%d-%H%M%S")}.txt')
            with open(path, 'w+') as tmp:
                tmp.write('')
                [tmp.write(f'{msg["type"]} : {msg["text"]}\n') for msg in self.messages]
            os.system(f'open -e {path}') if os.name == 'posix' else webbrowser.open(path)


# Get file path from config file
def get_file_name(code, extension, year):
    return app.config[code]['filename'][extension].format(year=year, yy=year[2:])


# Make path from application options
def get_master_file():
    year = str(app.args.year)
    for code in ['master', 'intensives', 'vgos']:
        if getattr(app.args, code, False):
            return Path(app.config['folder'], get_file_name(code, 'xlsx', year))


def get_password(name):
    global passwords

    if not passwords.get(name):
        tk.Tk().withdraw()
        passwords[name] = tkinter.simpledialog.askstring("Password", "Enter password:", show='*')
    return passwords[name]


def upload_files(parent, files, file_type, show=False):
    servers = toml.load(os.path.join(app.config['folder'], app.config.get('servers', 'servers.toml')))
    scp = app.config['scp'].get(file_type, None)
    if not scp:
        return

    # Copy to remote server
    server_name, remote_folder = scp['server'], scp['folder']
    commands, setmode = scp.get('commands', []), scp.get('setmode', False)
    if show and 'ls -l' not in commands:
        commands.append('ls -l')

    host = servers[server_name]
    if not host.get('id_rsa', '').strip():
        host['password'] = get_password(server_name)

    with Client(host) as server:
        if not server.connected:
            parent.exit(error=f'Could not connect to {server_name} {server.error}')

        for path in files:
            remote_path = str(PurePosixPath(remote_folder).joinpath(path.name))
            ok, msg = server.put_and_exec(str(path), remote_path, commands, setmode)
            if not ok:
                parent.exit(error=f'Could not copy {path.name} to {server_name} - {msg}')
            parent.add_information(msg)


def exec_commands(parent):
    if 'exec' not in app.config:
        return
    servers = toml.load(os.path.join(app.config['folder'], app.config.get('servers', 'servers.toml')))

    # Execute commands in exec
    for action in app.config['exec']:
        if action.get('command', ''):
            server_name = action['server']

            host = servers[server_name]
            if not host.get('id_rsa', '').strip():
                host['password'] = get_password(server_name)
            with Client(host) as server:
                if not server.connected:
                    parent.exit(error=f'Could not connect {action["server"]} {server.error}')
                msg = server.exec(action['command'])
                parent.add_information(msg)


