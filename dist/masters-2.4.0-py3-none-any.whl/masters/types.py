import pkg_resources
import json


def load_types():
    f = pkg_resources.resource_stream(__name__, 'data/types.json')
    return json.loads(f.read().decode('utf-8'))


SESSION_TYPES = load_types()


def get_session_type(code: str, name: str) -> str:
    """Type code for a session"""
    text = f"{name or ''},{code or ''},{dbc or ''}"
    for type_name, regex in RE_TYPES:
        type_name, n = regex.subn(type_name, text)
        if n:
            return type_name.upper()
    return name.upper()
